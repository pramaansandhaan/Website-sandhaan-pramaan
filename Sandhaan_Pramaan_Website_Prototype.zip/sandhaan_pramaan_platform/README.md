# Sandhaan Pramaan — Global Legal Document Finder (prototype)

## What's included
- `index.html`: responsive searchable directory prototype.
- Search by keyword, region, and category.
- Seed entries for India/Odisha and selected international official legal sources.

## Run locally
Open `index.html` in a modern browser. No build step or server is required for this static prototype.

## Publish
Upload `index.html` to a static website host or your existing hosting account. Connect a custom domain if desired. Review hosting provider terms and security settings before publishing.

## Important limitations
- This is a directory, not a live crawler or a complete government-document database.
- Links are starter entries. Verify each destination, current service workflow, fees, and access requirements before public launch.
- A public portal does not mean every record is downloadable without login.
- The “public access” filter is intentionally a reminder; it does not certify that a specific document is login-free.
- Do not collect passwords or OTPs, bypass CAPTCHA, payment gates, access controls, or privacy restrictions.
- Add a privacy notice, terms of use, contact information, and accessibility review before production.
- Keep a verification date and reviewer for each source when the directory is maintained.
